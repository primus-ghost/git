let card = JSON.parse(localStorage.getItem('card'))
export const addCart = (state = card, action) => {

    
    switch(action.type){
        case 'addToList':
            return state = JSON.parse(localStorage.getItem('card'))
        case 'increament':
            let fake_state = state
            let x = action.payload
            x.quantity+=1      
            return fake_state
        case 'decreament':
            let fake_state_2 = state
            let x_2 = action.payload
            if(x_2.quantity<=0){
                x_2.quantity=1
            }
            x_2.quantity-=1      
            return fake_state_2
        default:
            return state
            
    }
    
}

export default addCart
