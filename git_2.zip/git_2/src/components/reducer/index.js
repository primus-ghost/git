import { combineReducers } from 'redux'
import addCart from './AddCart'


const allReducer = combineReducers({
    addCart: addCart,
})

export default allReducer

