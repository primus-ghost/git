import React, { useState, useEffect, useRef } from 'react'
import { useSelector } from 'react-redux'

const Nested = ({ subjectId }) => {
    const childData = useSelector( state =>state.data )
    const [active, setActive] = useState([])

    useEffect(() => {
        setActive(childData)
    }, [childData])

    return (
        <ul className="child">
            {active.map((n, i)=> {
                if(n.parentId == subjectId){
                    return <li key={i}>{n.title}</li>
                }else{
                    return false
                }
            })}
        </ul>
    )
}

export default Nested
