import { mainSerivce } from "../service/mainSerivce";

export const allData = () =>{
    return async dispatch =>{
        const  { data }  = await mainSerivce();
        dispatch({type:'ALL_DATA' , payload: data.data})
    }
}
