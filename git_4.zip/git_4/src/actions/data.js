import axios from 'axios'

export const data = item => {
    return async dispatch => {

        const fetchItem = async () => {
            return await axios.get( `http://192.168.1.9:8021/v1/common/subject/parent/${item.subjectId}` ,{
                headers: {
                  'Authorization': 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxIiwiaWF0IjoxNjA5MDc0MDEyLCJleHAiOjE2MDk2Nzg4MTJ9.yFYo5cyGwMpxYTlXaruo_YXhDj5OwB6wXwpbMVUb9r23q30JvEvlVr5CYi6VdQYcp2kfHKNDy8PLpoExbKffFg' 
                }
            })
        }
        const  { data }  = await fetchItem();
        dispatch({type:'DATA' , payload: data.data})

    }
}