// import { fetchItem } from "../service/mainSerivce";

// export const isOpen = () => {
//     return async dispatch => {
//         const  { data }  = await fetchItem();
//         dispatch({type:'DATA' , payload: data.data})
//     }
// }