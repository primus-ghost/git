export const alldataReducer = (state= [], action) => {
    switch(action.type){
        case 'ALL_DATA':
            return action.payload
        default:
            return state    
    }
}