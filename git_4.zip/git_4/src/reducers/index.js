import { combineReducers } from 'redux'
import { alldataReducer } from './alldata'
import { dataReducer } from './data'
import { isopenReducer } from './isOpen'

export const allReducers = combineReducers({
    data: dataReducer,
    allData: alldataReducer,
    isOpen: isopenReducer
})