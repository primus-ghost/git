export const isopenReducer = (state= [] ,action) => {
    switch(action.type){
        case 'IS_OPEN':
            return action.payload
        case 'OPENED':
            return action.payload
        default: 
            return state
    }
}