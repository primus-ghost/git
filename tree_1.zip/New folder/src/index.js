import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

//here we most maek Provider and take a wrapper to all components in the project 
import { Provider } from 'react-redux'
import { createStore } from 'redux'
// we must pass the allReducers to store to build a store from state's
import allReducers from './components/reducer/Index'

// to pass the state into the components we most create store like this
const store  = createStore(allReducers)


ReactDOM.render(
//and take it to Provider now all state are availlble in all commonents 
<Provider store={store}>
    <React.StrictMode>
      <App />
    </React.StrictMode>
  </Provider>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
