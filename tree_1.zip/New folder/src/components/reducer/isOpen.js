// we are in reducer and do operation from action that we made it

// never nad ever let state be empty there is no way to have a empty state 
// we must take a inital value to state 

export const isOpen = (state= [], action) => {
    switch(action.type){          
        case'fetch':
            const fake_state = state
            console.log(action.payload)
            return fake_state
        default:
            return state     
    }
}

export default isOpen