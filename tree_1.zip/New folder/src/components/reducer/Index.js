// here we must comgine all reducer's in one file
import { combineReducers } from 'redux'
import {isOpen} from './isOpen'

const allReducers = combineReducers({
    isOpen: isOpen,
}) 

export default allReducers
