// here is action that we pass the action to reducers
export const collapse = () => {
    return{
        type: 'true'
    }
}