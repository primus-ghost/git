import React, { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import axios from 'axios'
import './Home.scss'
import isOpen from '../reducer/isOpen'

const Home = () => {
    const [fetch, setFetch] = useState([])
    const [loading, setLoading] = useState(false)
    const dispatch = useDispatch(isOpen)
    const state = useSelector(state => state.isOpen)


    useEffect(() => {
      const fetchData = ()=> {
        setLoading(true)
        axios.get(`http://192.168.1.9:8021/v1/common/area/level`, {
        headers: {
          'Authorization': `Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxIiwiaWF0IjoxNjA4NTMwMDEwLCJleHAiOjE2MDkxMzQ4MTB9.DHnD8bu6Ko8e7ltT-ww2VobdwvLYPYjfi9pNaOVBgPJpJwfKKWoTCP47a9LCeojXct5vL3OrvUjau1q6GDTZxg` 
        }
      })
      .then(rs=> setFetch(rs.data))
      setLoading(false)
    }
    fetchData()
  }, [])


  if(fetch.length==0){
    return(
      <h1>Loading...</h1>
    )
  }else{
    return (
      <div className="parent">
        {
          fetch.data.map((n, i)=> {
            return(
              <div key={i} onClick= {(e)=>dispatch({type: 'fetch', payload: n})}>
                                 
              </div>
            )
          })
        }
      </div>
    )
  }

  
}

export default Home
