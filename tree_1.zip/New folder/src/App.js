import './App.css';
import Home from './components/Home/Home';

function App() {
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;

// http://192.168.1.9:8021/v1/common/subject/tree difficulty normal
//http://192.168.1.9:8021/v1/common/subject/parent/0 difficulty very hard hard
// http://192.168.1.9:8021/v1/common/area/level difficulty: impossible