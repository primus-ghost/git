import React from 'react'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import './App.css';
import Main from './components/Main/Main';
import Header from './components/Header/Header'
import Products from './components/Products/Products';
import Produt from './components/Product/Produt';
import Cart from './components/Cart/Cart';


function App() {
  return (
    <Router>
      <div className="App">
        <Header/>
        <Switch>
          <Route exact path="/" component={Main}/>
          <Route path="/products" component={Products}/>
          <Route path="/product/:id" component={Produt}/>
          <Route path="/cart" component={Cart}/>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
