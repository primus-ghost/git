import React from 'react'
import './Main.scss'

const Main = () => {
   
    return (
        <div className="container">
           <h1>well come to your own site</h1>
        </div>
    )
}

export default Main
