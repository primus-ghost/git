import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { decreament, increament } from '../action/index'

import './Cart.scss'

const Cart = () => {
    const value = useSelector(state => state.Counter)
    const dispatch = useDispatch(increament, decreament)

    let card = JSON.parse(localStorage.getItem('card'))
    if(card===null){
        return(
            <h1>
                its empty
            </h1>
        )
    }else{
        return (
            <div>
               <ul className="cart">
                   {card.map((n, i)=> {
                       return(
                           <li key={i}>
                               <img src={n.img} alt=""/>
                                <h3>{n.title}</h3>
                                <h4>{n.price} $</h4>
                                <div className="holder">
                                    <button onClick={()=>dispatch(increament())}>+</button>
                                    <span className="value">{value}</span>
                                    <button className="negative" onClick={()=>dispatch(decreament())}>-</button>
                                </div>
                           </li>
                       )
                   })}
               </ul>
            </div>
        )    
    }
   
}

export default Cart
