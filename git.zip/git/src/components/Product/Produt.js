import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useSelector, useDispatch } from 'react-redux'
import { addList } from '../action/index'
import './Produt.scss'

const Produt = (props) => {
    const [data, setData] = useState({})
    const state = useSelector(state=>state.addCart)
    const dispatch = useDispatch(addList)
    

    useEffect(() => {
        axios.get(`https://fakestoreapi.com/products/${props.match.params.id}`)
        .then(rs=> setData(rs.data))
    }, [])

    const addCard = () => {
        let card = JSON.parse(localStorage.getItem('card'))
        let newcard = [...card, {
            id: data.id,
            title: data.title,
            price: data.price,
            img: data.image,
        }]
        
        let finded = card.find(n=>{
            return n.id  === data.id
        })
        if(!finded){
            localStorage.setItem('card', JSON.stringify(newcard))
            dispatch(addList())
        }else{
           alert(`IT'S AVAILBLE IN YOUR BAG MY FRIEND`)
        }
    } 

    return (
        <div className="product">
            <h1>this is product page</h1>
            <div className="product__img--holder">
                <img className="product__img" src={data.image} alt=""/>
            </div>
            <h1 className="product__title">{data.title}</h1>
            <p className="product__para">{data.description}</p>
            <span className="product__price">{data.price}$</span>

            <button onClick={addCard}>Add to card</button>
        </div>
    )
}

export default Produt
