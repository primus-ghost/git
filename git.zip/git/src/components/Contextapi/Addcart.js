// import React, { useState, useEffect } from 'react'

// export const CardContext = React.createContext()

// export const CartProvider = (props) => {
//     const [add, setAdd] = useState([])

//     useEffect(() => {
//         JSON.parse(localStorage.getItem('card'))
//         return () => {
//             localStorage.getItem('card', JSON.stringify())
//         }
//     }, [])

//     return (
//         <CardContext.Provider value={[add, setAdd]}>
//             {props.children}
//         </CardContext.Provider>
//     )
// }

// export default CartProvider
