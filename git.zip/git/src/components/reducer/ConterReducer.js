const CounterReducer = (state=1, action) => {
    if(state<1){
        return state = 1
    }
    switch (action.type) {
        case 'INCREAMENT':
            return state + 1;
        case 'DECREAMENT':
            return state - 1;
    
        default:
            return state
    }
}

export default CounterReducer