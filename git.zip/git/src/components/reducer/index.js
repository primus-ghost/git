import { combineReducers } from 'redux'
import addCart from './AddCart'
import ConterReducer from './ConterReducer'

const allReducer = combineReducers({
    addCart: addCart,
    Counter: ConterReducer
})

export default allReducer

