export const addCart = (state= JSON.parse(localStorage.getItem('card')), action) => {

    switch(action.type){
        case 'addToList':
            return state = JSON.parse(localStorage.getItem('card'))
        default:
            return state
    }
    
}

export default addCart
