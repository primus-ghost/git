export const addList = () => {
    return {
        type: 'addToList'
    }
}

export const removeList = () => {
    return {
        type: 'removeList'
    }
}

export const increament = () => {
    return {
        type: 'INCREAMENT'
    }
}
export const decreament = () => {
    return {
        type : 'DECREAMENT'
    }
}
