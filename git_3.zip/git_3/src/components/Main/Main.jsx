import React from 'react'
import Button from 'react-bootstrap/Button';
import Badge from 'react-bootstrap/Badge';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl';

import { useSelector, useDispatch } from 'react-redux'
import { addPerson } from '../../actions/persons';

const Main = () => {

    const dispatch = useDispatch()

    return (
        <div>
            <div className="form mt-5">
                members <Badge variant="info">0</Badge>
                    <InputGroup>
                        <InputGroup.Prepend>
                        <Button variant="success">+</Button>
                        </InputGroup.Prepend>
                        <FormControl
                            placeholder="Username"
                            aria-label="Username"
                            aria-describedby="basic-addon1"
                            onChangeCapture={(e)=>dispatch(addPerson(e.target.value))}
                        />
                    </InputGroup>
                <Button  variant="primary mt-2" onClick={(e)=> dispatch(addPerson())}>
                    show members
                </Button>
                <div variant="dark"></div>
            </div>
        </div>
    )
}

Main.propTypes = {

}

export default Main
