export const addPerson = fullname => {
    return async (dispatch , getState) => {
        const persons = [...getState().persons]
        //                or useSelector = (state=> state.persons)
        const person = {
            id: Math.floor(Math.random()*5000),
            fullname
        }
        persons.push(person)
        await dispatch({ type: 'ADD_PERSON', payload: persons })
        
    }
}

export const deletePerson = ()=> {
    return async (dispatch, getState) => {
        const persons = [...getState().persons]
    }
}