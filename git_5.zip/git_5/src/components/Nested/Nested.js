import React, { useState, useEffect, useRef } from 'react'
import { useSelector, useDispatch } from 'react-redux'



const Nested = ({ subjectId  }) => {
    const childData = useSelector( state =>state.data )
    const lol = useSelector( state => state.toggle)   


    const [active, setActive] = useState([])
    const dispatch = useDispatch() 

    useEffect(() => {
        setActive(childData)
    }, [childData])


    return (
        <ul className="child">

            {
                active.map(n=> {
                    return n.child.map((m, i)=> {
                        if(m.parentId == subjectId ) {
                            return <li key={i}>{m.title}</li>
                        }
                    })
                })
            }    
            
        </ul>
    )
}

export default Nested
