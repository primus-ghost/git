import React, { useState,useEffect, useRef }  from 'react'
import { useSelector, useDispatch } from 'react-redux'  
import './Main.scss'
import { allData } from '../../actions/alldata'
import { data } from '../../actions/data'
import Nested from '../Nested/Nested'
import { toggle } from '../../actions/toggle'
// import { isOpen } from '../../actions/isOpen'


const Main = () => {

  const dispatch = useDispatch()
  const state = useSelector(state => state.allData)
  const it = useSelector(state => state.data)


  useEffect(() => {
    dispatch(allData())      
  }, [])
  

  const id = 1
  

  // const toggle = async () => {
  //   const obj = [
  //     {
  //       id: 0,
  //       Fname: 'ali',
  //       Lname: 'karimi'
  
  //     },
  //     {
  //       id: 1,
  //       Fname: 'mehran',
  //       Lname: 'hashar'
  
  //     },
  //     {
  //       id: 2,
  //       Fname: 'reza',
  //       Lname: '2nafari'
  
  //     },
  //     {
  //       id: 3,
  //       Fname: 'mmd',
  //       Lname: 'kafar'
  
  //     },
      
  
  //   ]
  //   const myf = (n) => {
  //     return n.id == id 
  //   }
  //   const find = obj.findIndex(n=>myf(n))
  //   obj.splice(find, 1)
  //   console.log(obj)
  // }



  if(state.length === 0){
    return(
      <h1>Loading...</h1>
    )
  }else{
    return (
      <ul className="parent" onClick={toggle}>
        {
          state.map((item, i)=>{     
  
            return(
              <div key={i}> 

                <li className="title"  onClick={ async () => {

                  await dispatch(data(item))
                  await dispatch(allData(item))
              
                }}> 
                  { `-${item.title}`}
                </li>
                <Nested subjectId={item.subjectId} status={item.status}/>
                {/* {open ? <Nested subjectId={item.subjectId} status={item.status}/> : <ul></ul>} */}

              </div>
            )
          })
        }
      </ul>
    )
  }
}

export default Main











 /// OLD WAY TAHT I DID THIS BUT did'nt work


  //   axios.get(`http://192.168.1.9:8021/v1/common/area/level`, {
    //     headers: {
    //       'Authorization': `Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxIiwiaWF0IjoxNjA4NTMwMDEwLCJleHAiOjE2MDkxMzQ4MTB9.DHnD8bu6Ko8e7ltT-ww2VobdwvLYPYjfi9pNaOVBgPJpJwfKKWoTCP47a9LCeojXct5vL3OrvUjau1q6GDTZxg` 
    //     }
    //   })
    // .then(rs=>console.log(rs.data))