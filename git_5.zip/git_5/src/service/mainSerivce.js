import axios from 'axios'

export const mainSerivce = async () => {
  return await axios.get( `http://192.168.1.106:8021/v1/common/subject/parent/0` ,{
    headers: {
      'Authorization': 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxMDEiLCJpYXQiOjE2MDkzMjk2NTUsImV4cCI6MTYwOTkzNDQ1NX0.9imYtQOUdIDxxWCHXffntFA30gzGnPmirLSU78pSBDCck3m27SjhGYyCtuNlwWIyj6vYMDJR9VnZWJoqU4Uneg' 
    }
  });
};

export const fetchItem = async item => {
  return await axios.get( `http://192.168.1.106:8021/v1/common/subject/parent/${item.subjectId}` ,{
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxMDEiLCJpYXQiOjE2MDkzMjk2NTUsImV4cCI6MTYwOTkzNDQ1NX0.9imYtQOUdIDxxWCHXffntFA30gzGnPmirLSU78pSBDCck3m27SjhGYyCtuNlwWIyj6vYMDJR9VnZWJoqU4Uneg' 
      }
  })
}