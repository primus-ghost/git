export const toggleReducer = (state= [] ,action) => {
    switch(action.type){
        case 'TOGGLE':
            return action.payload
        default:
            return state
    }
}