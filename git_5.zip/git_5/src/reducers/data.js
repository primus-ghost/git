export const dataReducer = (state=[], action) => {
    switch(action.type){
        case 'DATA':
            return [...state ,action.payload]
            // return [...state ,action.payload]

        default:
            return state
    }
}