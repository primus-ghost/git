import { combineReducers } from 'redux'
import { alldataReducer } from './alldata'
import { dataReducer } from './data'
import { toggleReducer } from './toggle'

export const allReducers = combineReducers({
    data: dataReducer,
    allData: alldataReducer,
    toggle: toggleReducer
})