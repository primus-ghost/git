export const toggle = (newItem) => {
    return async (dispatch, getState) => {
        // let id = 176
        // const myf = (n) => {
        //     return n.subjectId == id 
        // }
        // const find = newItem.findIndex(n=>myf(n))
        // newItem.splice(find, 1)

        // console.log(newItem)
        // dispatch({ type: 'TOGGLE' , payload: newItem})
    }
}