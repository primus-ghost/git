import { fetchItem } from '../service/mainSerivce';

export const data = oldItem => {
    return async dispatch => {
        const  { data }  = await fetchItem(oldItem)
        const newItem = {...oldItem, child: data.data}
        
        dispatch({type:'DATA' , payload: newItem})
    }
}