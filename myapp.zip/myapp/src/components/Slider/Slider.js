import React, { useState, useEffect, useRef } from 'react'
import Slide from '../Slide/Slide'
import './Slider.scss'
import img_1 from "../../img/img-01.jpg"
import img_2 from "../../img/img-02.jpg"
import img_3 from "../../img/img-03.jpg"
import img_4 from "../../img/img-04.jfif"
import img_5 from "../../img/img-05.jpg"
import arrow_svg from '../../img/right-arrow.png'
import Dots from '../Dots/Dots'

const Slider = () => {
    const slides = [
        { 
            image: img_1,
            title: "wellcome to your own site"
        }, 
        { 
            image: img_2,
            title: "can you help us?! sheare it"
        }, 
        { 
            image: img_3,
            title: "imporve your skill"
        }, 
        { 
            image: img_4,
            title: "jsut do it and go a head"
        }, 
        { 
            image: img_5,
            title: "jsut do it and go a head"
        }
    ]
    const [width, setWidth] = useState(0)
    
    const firtSlide = slides[0]
    const secondSlide = slides[1]
    const lastSlide = slides[slides.length-1]

    const slideRef = useRef()
    const autoPlayRef = useRef()
    const transitionRef = useRef()

    const [state, setState] = useState({
        translate: 0,
        activeSlide: 0,
        _slides: [
            firtSlide,
            secondSlide,
            lastSlide
        ]
    })

    const { translate, activeSlide, _slides } = state;

    useEffect(() => {
        const getWidth = () => slideRef.current.offsetWidth
        setWidth(getWidth)
        console.log(_slides)
    }, [])

    useEffect(() => {
        autoPlayRef.current = nextSlide
        transitionRef.current = transitionSmooth
    })

    useEffect(() => {
        
        const play = () => {
            autoPlayRef.current()
        }

        const smooth = () => {
            transitionRef.current()
        }
    
        const interval = setInterval(play, 5000)
        const transitionEnd = window.addEventListener("transitionend", smooth)

        return () => {
            clearInterval(interval)
            window.removeEventListener('transitionend', transitionEnd)
        }
    }, [])

    const nextSlide = () => {
        if(activeSlide === slides.length - 1){
            return setState({...state,
                translate: 0,
                activeSlide: 0 
            })
        }
        setState({...state,
            translate: (activeSlide+1) * width,
            activeSlide: activeSlide + 1
        })
    }

    const prevSlider = () => {
        if(activeSlide === 0 ){
            return setState({...state,
                translate: (slides.length - 1) * width,
                activeSlide: slides.length-1
            })
        }
        setState({...state,
            translate: (activeSlide - 1) * width,    
            activeSlide:  activeSlide - 1
        })
    }

    const transitionSmooth = () => {
        let _slides = []
        if(activeSlide === slides.length - 1){
            _slides = [slides[slides.length - 2], lastSlide, firtSlide]
        }else if(activeSlide === 0) {
            _slides = [lastSlide, firtSlide, secondSlide]
        }else{
            _slides = slides.slice(activeSlide - 1, activeSlide + 2)
        }
        setState({...state,
            _slides,
        })
    }

    return (
        <div className="carousel__wrap">

            <div className="carousel__inner">       
                <div className="carousel__container" ref={slideRef}>
                    {slides.map((item, index)=> {
                        return <Slide 
                            slideImg={item.image}
                            translate={translate}
                        />
                    })}
                </div>
            </div>

            <button className="btn__arrow btn__arrow--right" onClick={nextSlide}>
                <img src={arrow_svg} alt=""/>
            </button>

            <button className="btn__arrow btn__arrow--left" onClick={prevSlider}>
                <img src={arrow_svg} alt=""/>
            </button>

            <div className="carouesl__dots--wrapper">
                <Dots slides={slides} activeSlide={activeSlide}/>
            </div>

        </div>
        
    )
}

export default Slider
