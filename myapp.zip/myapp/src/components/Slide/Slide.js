import React, { useState, useEffect, useRef, useMemo } from 'react'
import './Slide.scss'
import arrow_svg from '../../img/right-arrow.png'

const Slide = ({slideImg, translate}) => {
    useMemo(() => Slide)
    return (
        <div className="carousel__slide">
            <img src={slideImg} alt="" className="carousel__slide--img" style={{transform: `translateX(-${translate}px)`}}/>
        </div>
        
    )
}

export default Slide
