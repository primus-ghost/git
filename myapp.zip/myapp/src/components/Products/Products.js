import React,  { useState, useEffect }from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import './Products.scss'

const Products = (props) => {
    const [data, setData] = useState([])
    useEffect(() => {
        axios.get(`https://fakestoreapi.com/products`)
        .then(rs=> setData(rs.data))
    }, [])

    if(data.length === 0){
        return(
            <h1>loading....</h1>
        )
    }else{
        return (
      
            <div className="parent">
                
                {
                    data.map((n, i)=> {
                        return(
                            <div className="box" key={i}>
                                <span className="cate">{n.category}</span>
                                <div className="img-holder">
                                    <img src={n.image} alt=""/>
                                </div>
                                <h2 className="title">{n.title}</h2>
                                <span className="price">{n.price}$</span>
                                <button>
                                    <Link to={`/product/${n.id}`} as={`/product/:id`}>
                                        more info
                                    </Link>
                                </button>
                            </div>
                        )    
                        })
                    }
            </div>
    
           )
    }
   

    
}

export default Products
