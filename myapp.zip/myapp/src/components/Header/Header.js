import React from 'react'
import {Link} from 'react-router-dom'
import { useSelector } from 'react-redux'
import './Header.scss'

const Header = () => {
    const state = useSelector(state=>state.addCart)
    const nav = [
        {
            title: 'Main',
            url: '/'
        },
        {
            title: 'Products',
            url: '/products'
        }
    ]
   
    console.log()

    return (
        <ul className="nav">
            {
                nav.map((n, i)=>{
                    return (
                        <li key={i}>
                            <Link to={n.url}>{n.title}</Link>
                        </li>
                    )
                })
            }

            <li>
                <Link to="/cart">Cart</Link>
                <div className="badgge">{state.length}</div>
            </li>
        </ul>
    )
}

export default Header
