import React, {useState} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { decreament, increament,  } from '../action/index'
import './Cart.scss'

const Cart = () => {  
    const state = useSelector(state=>state.addCart)
    const dispatch = useDispatch(increament, decreament)
    const [data, setData] = useState(false)


    if(state.length ===0){
        return(
            <h1>
                your cart is empty 
            </h1>
        )
    }else{

        // const increase = (id) => {
        //     let finded = state.findIndex(n=> n.id === id)
        //     let Card = state[finded]
        //     let quan = Card.quantity+1;
        //     let item = {...Card, quantity: quan}
        //     console.log(state)
            
        //     let newCard = state.splice(finded, 1, item)
        //     let end = [...state, newCard];
        //     localStorage.setItem('card', JSON.stringify(end))
            
        // }



        // const decrease = (id) => {
        //     let finded = state.findIndex(n=> n.id === id)
        //     let Card = state[finded]
        //     let quan = Card.quantity-1;
        //     let item = {...Card, quantity: quan}
        //     let newCard = state.splice(finded, 1 , item)
        
        // }
        return (
            <div>
               <ul className="cart">
                   {state.map((n, i)=> {
                     
                       return(
                           <li key={i}>
                               <img src={n.img} alt=""/>
                                <h3>{n.title}</h3>
                                <h4>{n.price} $</h4>
                                <div className="holder">
                                    
                                    <button onClick={()=>{
                                        setData(!data)
                                        dispatch({type: 'increament', payload: n})
                                    }}>+</button>

                                    <span className="value">{n.quantity}</span>

                                    <button className="negative" onClick={()=>{
                                            setData(!data)
                                            dispatch({type: 'decreament', payload: n})
                                        }
                                    }>-</button>

                                </div>
                                <button>save</button>
                           </li>
                       )
                   })}
               </ul>
            </div>
        )    
    }
   
}

export default Cart
