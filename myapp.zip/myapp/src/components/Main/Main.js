import React from 'react'
import Slider from '../Slider/Slider'
import './Main.scss'

const Main = () => {
   
    return (
        <div className="container">
           <h1>well come to your own site</h1>

            <Slider/>

        </div>
    )
}

export default Main
