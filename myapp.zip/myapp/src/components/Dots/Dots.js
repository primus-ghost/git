import React from 'react'
import Slide from '../Slide/Slide'
import './Dots.scss'

const Dots = ({ slides, activeSlide }) => {
    return(
        <div>
            {slides.map((slide, index)=> {
                return <span key={slide}  className={`dots ${activeSlide === index ? "active" : ""}`} />
            })}
        </div> 
    )
}

export default Dots
